#!/bin/bash

for i in /home/thomasbeder/Essential_genes_AnG/homolgFeatures/adapted_psiblast_outfmt/Sc/Seqs/*psiBlast*; 
do
 sample_name=`echo ${i} | awk -F "*psiBlast*" '{print $1}'`
 
cat ${i} add.txt > ${i}.cat
echo "$sample_name done!"
done



