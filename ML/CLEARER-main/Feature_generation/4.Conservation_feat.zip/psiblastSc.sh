#!/bin/bash

for i in /home/thomasbeder/Essential_genes_AnG/homolgFeatures/adapted_psiblast_outfmt/Sc/Seqs/*.fa; 
do
 sample_name=`echo ${i} | awk -F ".fa" '{print $1}'`
 
~/bin/ncbi-blast-2.9.0+/bin/psiblast -db ~/Malaria_DFG_Projekt/Eunice/Loc3/refseq_protein.00/refseq_protein.00  -query ${i} -out ${i}.psiBlast.tab -outfmt "6 qseqid sseqid pident length qlen slen evalue bitscore" -evalue 0.01 -num_threads 1 -max_target_seqs 5000

echo "$sample_name done!"
done


