import pandas as pd

def get_unique_protein():
    # extract needed columns from file downloaded from STRING DB
    #### This code will be used to read in the input data if complete PPI data was downloaded from STRING ###
    # dat = pd.read_csv('Dm_ppi.txt', sep='\s', engine='python')
    #####
    def strip(x):
        return x.replace('7227.', '')

    ## The header will be protein1 and protein2 if complete PPI data was used
    dat = pd.read_csv('string_interactions.tsv', sep='\t')[['node1_string_id','node2_string_id']]
    dat = dat.applymap(strip)  # clean the raw data from STRING

    dat.to_csv('output/string_interactions_extract.csv', index=False)  # write cleaned data to file for downstream analysis
    print(dat.head())

    # get unique protein from a PPI file
    allprots = dat['node1_string_id'].tolist()
    allprots.extend(dat['node2_string_id'].tolist())
    print('Number of protein in raw file %d' %len(allprots))
    allprots = set(allprots)
    print('Number of Unique protein in raw file %d' %len(allprots))
    res = pd.Series(list(allprots))
    res.to_csv('output/unique_prots.csv', index=False)

    print('Completed - 2 output files generated!')

if __name__ == '__main__':
    print('Program is running...')
    get_unique_protein()